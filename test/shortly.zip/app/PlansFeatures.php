<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlansFeatures extends Model
{
    protected $table = "plans_features";
}
