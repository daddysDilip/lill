<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlansFeatureMapping extends Model
{
    //
}
