<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupLinksMapping extends Model
{
    protected $table = "groups_links_mapping";
    public $timestamps = false;

    
}
