<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserMailMap extends Model
{
    protected $table = "user_email_map";
}
