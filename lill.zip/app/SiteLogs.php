<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteLogs extends Model
{
    protected $table = "site_logs";
}
