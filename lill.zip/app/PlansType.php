<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlansType extends Model
{
    //
}
