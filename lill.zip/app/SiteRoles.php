<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteRoles extends Model
{
    protected $table = "site_roles";
}
