<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmsTemplates extends Model
{
    protected $table = "sms_templates";
}
